package com.sachin.premium;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class RoundService extends Service {
    private static final String CHANNEL = "sachin_premium_sync";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String latestPeriod = "Waiting for live data";
    private final Runnable poller = new Runnable() {
        @Override public void run() {
            new Thread(() -> fetchAndStore()).start();
            handler.postDelayed(this, 15000);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "SACHIN PREMIUM PRO live sync", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Fetches and caches public round results while the app is active in the background.");
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(11, makeNotification());
        handler.removeCallbacks(poller);
        handler.post(poller);
        return START_STICKY;
    }
    private void fetchAndStore() {
        HttpURLConnection conn = null;
        try {
            URL url = new URL("https://draw.ar-lottery01.com/WinGo/WinGo_1M/GetHistoryIssuePage.json");
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            StringBuilder body = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) body.append(line);
            }
            JSONObject json = new JSONObject(body.toString());
            String period = "Live data updated";
            if (json.has("data") && json.getJSONObject("data").has("list")) {
                if (json.getJSONObject("data").getJSONArray("list").length() > 0) {
                    period = json.getJSONObject("data").getJSONArray("list").getJSONObject(0).optString("issueNumber", period);
                }
            }
            getSharedPreferences("round_cache", MODE_PRIVATE).edit().putString("history_json", body.toString()).putString("latest_period", period).putLong("updated_at", System.currentTimeMillis()).apply();
            latestPeriod = "Latest period: " + period;
            handler.post(this::updateNotification);
        } catch (Exception e) {
            latestPeriod = "Sync waiting - check network";
            handler.post(this::updateNotification);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
    private Notification makeNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_popup_sync).setContentTitle("SACHIN PREMIUM PRO live sync").setContentText(latestPeriod).setContentIntent(pending).setOngoing(true).build();
    }
    private void updateNotification() {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.notify(11, makeNotification());
    }
    @Override public void onDestroy() { handler.removeCallbacks(poller); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
