# SACHIN PREMIUM PRO (Key-free build)

This Android WebView app preserves the RUX-style dark neon layout and the original random BIG/SMALL + main/backup number generation pattern, but removes Firebase premium-key authentication and coin deduction.

## Important accuracy note
The prediction routine uses JavaScript `Math.random()`; it is not AI and cannot reliably forecast future outcomes. The app does not guarantee wins. Historical result rows show actual returned results, not fabricated win-rate claims.

## Background sync
A visible Android foreground data-sync service requests the public history endpoint every 15 seconds and stores the response locally. When the app is open, its page reads that cache and also refreshes the endpoint. Android/OEM battery controls, network availability, force-stop, and OS service limits can interrupt background sync; continuous operation is not guaranteed.

Build with `gradle assembleDebug` (JDK 17, Android SDK 35).
