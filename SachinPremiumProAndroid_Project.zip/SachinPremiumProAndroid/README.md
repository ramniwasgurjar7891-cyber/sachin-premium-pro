# SACHIN PREMIUM PRO Android wrapper

This project packages the user's supplied RUX PREMIUM PRO HTML in an Android WebView. The only HTML text change is the visible product name/title to SACHIN PREMIUM PRO; the original HTML styling and JavaScript prediction/history logic are retained.

## Build
Upload the *contents* of this project folder to the repository root, then run the GitHub Actions workflow `.github/workflows/build-apk.yml`.

## Important behavior and limitations
- The supplied HTML itself uses random BIG/SMALL prediction generation. It is not an AI forecast.
- The supplied HTML's pre-login winning feed and pre-login sample history are simulated by its own source code; they should not be treated as verified real wins.
- The page fetches the WinGo history endpoint and uses the Firebase configuration already present in the uploaded source. Availability depends on those external services and WebView/network behavior.
- The Android foreground service maintains a notification/status timer. It does not guarantee that the HTML WebView continues polling while the screen is off. Android may pause WebView JavaScript or stop services due to force-stop, battery management, or device policies.
- This is a debug APK workflow, not a Play Store release build.
